<?php
// Pastikan ini adalah request POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Ambil data dari form
    $caption = $_POST["caption"];
    $imageFile = $_FILES["image"]["name"];

    // Lakukan operasi yang diperlukan, misalnya menyimpan data ke database
    // Simpan data atau lakukan operasi lain sesuai kebutuhan

    // Berikan respons kembali ke halaman web
    $response = array("message" => "Form submitted successfully!", "caption" => $caption, "image" => $imageFile);
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // Jika bukan request POST, kirim respons dengan error
    $response = array("error" => "Invalid request method.");
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
