const hamBurger = document.querySelector(".toggle-btn");

hamBurger.addEventListener("click", function () {
  document.querySelector("#sidebar").classList.toggle("expand");
});

// FORM
function submitForm() {
    const form = document.getElementById("postForm");
    const formData = new FormData(form);

    // Kirim data form ke server menggunakan AJAX
    fetch("upload.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("output").innerText = JSON.stringify(data, null, 2);
    })
    .catch(error => console.error("Error:", error));
}
// SLIDE
document.addEventListener("DOMContentLoaded", () => {
    const carousel = document.querySelector(".carousel");
    const scrollStep = carousel.firstElementChild.offsetHeight; // Ukuran per langkah scroll

    document.getElementById("up").addEventListener("click", () => {
        carousel.style.transform = `translateY(-${scrollStep}px)`;
    });

    document.getElementById("down").addEventListener("click", () => {
        carousel.style.transform = `translateY(${scrollStep}px)`;
    });
});
